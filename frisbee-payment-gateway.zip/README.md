# Frisbee payment gateway for Joomla 2+ and Virtuemart 2+

## System requirements

* PHP 5.6+
* Joomla 2+
* Virtuemart 2+

## Installation

1. [Download frisbee-payment-gateway.zip](https://github.com/frisbee-ua/joomla-virtuemart-payment-gateway/blob/master/frisbee-payment-gateway.zip?raw=true)
2. Go to Joomla's administration panel
3. Go to extension manager
4. Install the module package
